// Use import to gain access to all Java utility classes for file input/output.
import java.io.*;
import java.util.*;

public class ReadAFile
{
  // Create a new keyboard Scanner object.
  static Scanner keyboard = new Scanner(System.in);
    
  public static void main(String[] args)
  {      
    String fileName = null;
    String line = null;
        
    // Reading a file is "risky" since the file might not exist.
    try
    { 
      System.out.print("Enter a filename: ");
      fileName = keyboard.next();
      
      // Creates a File object that holds the directory/filename.
      // You may also express a specific file name such as "C:\\Docs\\theFile.txt"
      // It's OK to declare theFile here
      File theFile = new File(fileName);   
      
      //create a Scanner object to read from the file
      //It's OK to declare the input scanner here
      Scanner input = new Scanner(theFile);
               
      // An exception is thrown if you try to read past the end-of-file.
      while(input.hasNext())
      {
    	//Read the next line of input
    	line = input.nextLine();
        // Simply print out each line to the text console screen.
        System.out.println(line);
      }//while
      
      // Closing a file is also "risky" and must be inside a try.
      input.close();
      keyboard.close();
    }//try
    catch(Exception ex)
    {
      System.out.println("Oops, something went wrong!");
    }//catch
  }//main
}//ReadAFile