import java.text.DecimalFormat;
/**
* @author Trevor Golusinski <br>
* Prog 7 <br>
* Due Date and Time: April 22nd, 2021 before 9:00 AM <br>
*
* Purpose: The purpose of this program is to assist a user in shopping, by keeping
*			track of their items, costs, and names of items, with the initial
*			items being collected from a file. <br>
*
* Input: The user will input a file name, then input their menu choice, and will 
* 			follow the on-screen instructions that are displayed after each choice. <br>
*
* Output: The program will output a response to every user input, and will display
*			information such as number of items, cost of each item, item names,
*			etc, all based on user input. <br>
*
* Certification of Authenticity:
* I certify that this lab is entirely my own work. <br>
 */
public class ShoppingCartGolusinski 
{
	/**
	 * Instance array to hold the user's items.
	 */
	ItemGolusinski[] myItems;
	
	/**
	 * Instance variable to hold the size of the array.
	 */
	int mySize;
	
	/**
	 * A DecimalFormat variable to ensure that all money-related values are printed
	 * in a money-style format ($.$$).
	 */
	static DecimalFormat moneyStyle = new DecimalFormat("0.00");
	/**
	 * This null constructor will set default values for the instance variables, to
	 * help identify if there are any errors in the code.
	 */
	public ShoppingCartGolusinski() 
	{
		myItems = new ItemGolusinski[10];
		mySize = 0;
		
		//Initialize each item to null 
		for (int i = 0; i < myItems.length; i++)
			myItems[i] = null;
	}// ShoppingCartGolusinski null constructor

	/**
	 * This getter method will return the amount of items in the shopping cart.
	 * @return mySize the Size of the shopping cart array
	 */
	public int getSize() 
	{
		return mySize;
	}// getSize

	/**
	 * This addToCart method will add an item to the cart array.
	 * @param item A given item, provided by the user.
	 * @return true or false (based on conditions)
	 */
	public boolean addToCart(ItemGolusinski item) 
	{	
		boolean ans = false;
		
		//If the list is not full, add the item.
		if (mySize < myItems.length)
			{
				myItems[mySize] = item;
				mySize++;
				ans = true;
			}//if statement
		return ans;
	}// addToCart

	/**
	 * This method will loop through every item in the array, ignoring
	 * any null values, and find the most expensive item.
	 * @return maxItem The most expensive item in the array.
	 */
	public ItemGolusinski findMostExpensive() 
	{		
		ItemGolusinski maxItem = null;
		double maxPrice = myItems[0].getPrice();
		maxItem = myItems[0];
		for (int i = 1; i < mySize; i++)
			if (myItems[i].getPrice() > maxPrice) 
			{
				maxPrice = myItems[i].getPrice();
				maxItem = myItems[i];				
			} // if statement
		return maxItem;
	}// findMostExpensive

	/**
	 * This method will loop through every item in the array, ignoring
	 * any null values, and find the least expensive item.
	 * @return minItem The least expensive item in the array.
	 */
	public ItemGolusinski findLeastExpensive() 
	{
		ItemGolusinski minItem = null;
		double minPrice = myItems[0].getPrice();
		minItem = myItems[0];
		for (int i = 1; i < mySize; i++)
			if (myItems[i].getPrice() < minPrice) 					
			{
				minPrice = myItems[i].getPrice();
				minItem = myItems[i];				
			} // if statement
		return minItem;
	}// findLeastExpensive

	/**
	 * This method will calculate the total amount of all items in the array.
	 * @return total The total cost of all items in the array.
	 */
	public double calcTotal() {
		double total = 0;
		double price = 0;
		double quantity = 0;
		for (int i = 0; i < mySize; i++) 
		{
			price = myItems[i].getPrice();
			quantity = myItems[i].getQuant();
			total += (price * quantity);
		} // for loop
		return total;
	}// calcTotal

	/**
	 * This printList method will print out a description of each item in the list,
	 * consisting of the name, quantity, and individual price.
	 */
	public void printList() {
		int printCheck = 0;
		for (int i = 0; i < mySize; i++) 
		{	
			System.out.println("Item " + (i + 1) + ": ");
			System.out.println(myItems[i].toString());
			printCheck++;
		} // for loop
		if (printCheck == 0)
			System.out.println("There are no items in the cart.");
	}// printList

	/**
	 * This "extra for experts" challenge will identify the highest priced item in the
	 * cart, and remove it from the cart.
	 * @param shopping The shopping cart (array) of all items the user provides.
	 */
	public void deleteItem(ShoppingCartGolusinski shopping) 
	{
		int maxPosition = 0;
		double maxPrice = 0;
		if (mySize >= 1)
		{
			for (int i = 0; i < mySize; i++)
				if (myItems[i] != null)
					if (myItems[i].getPrice() > maxPrice) 
					{
						maxPosition = i;
						maxPrice = myItems[maxPosition].getPrice();
					} // if statement
			System.out.println(myItems[maxPosition].getName() + " successfully deleted!");
			myItems[maxPosition] = myItems[mySize - 1];
			myItems[mySize - 1] = null;
			mySize--;
		} //if statement
		else
			System.out.println("No items were deleted, as there are no items in the cart.");
	}// deleteItem
}// ShoppingCartGolusinski
