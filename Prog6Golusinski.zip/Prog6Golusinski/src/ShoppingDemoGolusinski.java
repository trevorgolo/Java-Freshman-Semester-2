import java.util.*;

/**
* @author Trevor Golusinski <br>
* Prog 6 <br>
* Due Date and Time: April 15th, 2021 before 9:00 AM <br>
*
* Purpose: The purpose of this program is to assist a user in shopping, by keeping
*			track of their items, costs, and names of items. <br>
*
* Input: The user will input their menu choice, and will follow the on-screen
*			instructions that are displayed after each choice. <br>
*
* Output: The program will output a response to every user input, and will display
*			information such as number of items, cost of each item, item names,
*			etc, all based on user input. <br>
*
* Certification of Authenticity:
* I certify that this lab is entirely my own work. <br>
 */
public class ShoppingDemoGolusinski 
{

	/**
	 * Declaration statement to initialize a scanner to intake user input.
	 */
	static Scanner keyboard = new Scanner(System.in);

	/**
	 * The main method, where all of the method referencing and most of the
	 * display will take place.
	 * @param args An array of strings that is used by the main method.
	 */
	public static void main(String[] args) 
	{
		ShoppingCartGolusinski cart = new ShoppingCartGolusinski();
		String fakeMenuInput;
		char menuInput;
		String name;
		int quantity;
		double price;
		boolean addedToCart;

		System.out.println("Welcome! This program will help you go shopping!");
		System.out.println(cart.mySize);
		do 
		{

			System.out.println("\nPlease choose an item from the following menu:" + "\nA - Add an Item to the Cart"
					+ "\nL - Find the Least Expensive Item in the Cart"
					+ "\nM - Find the Most Expensive Item in the Cart" + "\nN - Find the Number of Items in the Cart"
					+ "\nT - Find the Total Cost of All Items in the Cart"
					+ "\nP - Print Out Details About All Items in the Cart"
					+ "\nD - Delete the Most Expensive Item from the Cart" + "\nQ - Quit");
			System.out.print("Please select an item: ");
			fakeMenuInput = keyboard.next();
			fakeMenuInput = fakeMenuInput.toLowerCase();
			menuInput = fakeMenuInput.charAt(0);

			//A switch statement to use a case-by-case basis for each user input.
			switch (menuInput) 
			{
			case 'a':
				System.out.print("Please enter the item name: ");
				name = keyboard.next();
				System.out.print("Please enter the quantity: ");
				quantity = keyboard.nextInt();
				System.out.print("Please enter the individual price of the item: ");
				price = keyboard.nextDouble();
				ItemGolusinski item = new ItemGolusinski(name, quantity, price);
				addedToCart = cart.addToCart(item);
				if (addedToCart) {
					System.out.println(name + " has been added to the cart!");
				} // if statement
				else {
					System.out.println(name + " could not be added to the cart.");
				} // else statement
				break;
			case 'l':
				if (cart.findLeastExpensive() != null)
					System.out.println("The least expensive item is: \n" + cart.findLeastExpensive());
				else
					System.out.println("There are no items in the cart.");
				break;
			case 'm':
				if (cart.findMostExpensive() != null)
					System.out.println("The most expensive item is: \n" + cart.findMostExpensive());
				else
					System.out.println("There are no items in the cart.");
				break;
			case 'n':
				System.out.println("The cart has " + cart.getSize() + " item(s).");
				break;
			case 't':
				System.out.printf("The cart total is: $%1.2f", cart.calcTotal());
				break;
			case 'p':
				cart.printList();
				break;
			case 'd':
				cart.deleteItem(cart);
				break;
			case 'q':
				break;
			default:
				System.out.println("Unable to read input. Please try again.");
			}// switch statement
		} // large do loop
		while (menuInput != 'q');
		System.out.println("Thank you for using this program! Goodbye!");
		keyboard.close();
	}// main
}// ShoppingDemoGolusinski
