/**
* @author Trevor Golusinski <br>
* Prog 6 <br>
* Due Date and Time: April 15th, 2021 before 9:00 AM <br>
*
* Purpose: The purpose of this program is to assist a user in shopping, by keeping
*			track of their items, costs, and names of items. <br>
*
* Input: The user will input their menu choice, and will follow the on-screen
*			instructions that are displayed after each choice. <br>
*
* Output: The program will output a response to every user input, and will display
*			information such as number of items, cost of each item, item names,
*			etc, all based on user input. <br>
*
* Certification of Authenticity:
* I certify that this lab is entirely my own work. <br>
 */
public class ItemGolusinski 
{
	/**
	 * Instance variable to hold the name of the item.
	 */
	String myName;
	/**
	 * Instance variable to hold the quantity of a given item.
	 */
	int myQuant;
	/**
	 * Instance variable to hold the individual price of a given item.
	 */
	double myPrice;

	/**
	 * The null constructor sets a certain value to each variable in order to
	 * identify if there is an error in the code.
	 */
	public ItemGolusinski() 
	{
		myName = "EMPTY";
		myQuant = 0;
		myPrice = 0.0;
	}// ItemGolusinski null constructor

	/**
	 * The full constructor sets up assignment statements to update variables as
	 * they are changed throughout the program's execution.
	 * @param newName A new, user-entered name for an item.
	 * @param newQuant A new, user-entered quantity of a specific item.
	 * @param newPrice A new, user-entered price for an individual item.
	 */
	public ItemGolusinski(String newName, int newQuant, double newPrice) 
	{
		myName = newName;
		myQuant = newQuant;
		myPrice = newPrice;
	}// ItemGolusinski full constructor

	/**
	 * This getter method will return the value of name.
	 * @return myName The name of a given item.
	 */
	public String getName() 
	{
		return myName;
	}// getName

	/**
	 * This setter method will set a new string of name in place of the old string.
	 * @param newName The new name of an item, given by the user.
	 */
	public void setName(String newName) 
	{
		myName = newName;
	}// setName

	/**
	 * This getter method will return the value of myQuant, the quantity of items.
	 * @return myQuant The quantity of a given item.
	 */
	public int getQuant() 
	{
		return myQuant;
	}// getQuant

	/**
	 * This setter method will set the value of myQuant to a new value, based on
	 * user input.
	 * @param newQuant The new quantity of an item, given by the user.
	 */
	public void setQuant(int newQuant) 
	{
		myQuant = newQuant;
	}// setQuant

	/**
	 * This getter method will return the value of myPrice, the price of an item.
	 * @return myPrice The individual price of an item.
	 */
	public double getPrice() 
	{
		return myPrice;
	}// getPrice

	/**
	 * This setter method will set the price to a new value given by the user.
	 * @param newPrice The new price of an individual item, given by the user.
	 */
	public void setPrice(int newPrice) 
	{
		myPrice = newPrice;
	}// setPrice

	/**
	 * This toString method will print out details of a given item, such as the
	 * name, quantity, and price for each individual item.
	 */
	public String toString() 
	{
		String ans = "Item Name: " + myName + "\n";
		ans += "Quantity: " + myQuant + "\n";
		ans += "Individual Price: $" + myPrice;
		return ans;
	}// toString
}// ItemGolusinski
