/**
* @author Trevor Golusinski <br>
* Prog 6 <br>
* Due Date and Time: April 15th, 2021 before 9:00 AM <br>
*
* Purpose: The purpose of this program is to assist a user in shopping, by keeping
*			track of their items, costs, and names of items. <br>
*
* Input: The user will input their menu choice, and will follow the on-screen
*			instructions that are displayed after each choice. <br>
*
* Output: The program will output a response to every user input, and will display
*			information such as number of items, cost of each item, item names,
*			etc, all based on user input. <br>
*
* Certification of Authenticity:
* I certify that this lab is entirely my own work. <br>
 */
public class ShoppingCartGolusinski 
{
	/**
	 * Instance array to hold the user's items.
	 */
	ItemGolusinski[] myItems;
	
	/**
	 * Instance variable to hold the size of the array.
	 */
	int mySize;

	/**
	 * Instance variable to hold the variable that is used to keep item count for the
	 * addToCart function.
	 */
	int j = 0;
	/**
	 * This null constructor will set default values for the instance variables, to
	 * help identify if there are any errors in the code.
	 */
	public ShoppingCartGolusinski() 
	{
		myItems = new ItemGolusinski[10];
		mySize = 0;
	}// ShoppingCartGolusinski null constructor

	/**
	 * This getter method will return the amount of items in the shopping cart.
	 * @return mySize the Size of the shopping cart array
	 */
	public int getSize() 
	{
		return mySize;
	}// getSize

	/**
	 * This addToCart method will add an item to the cart array.
	 * @param item A given item, provided by the user.
	 * @return true or false (based on conditions)
	 */
	public boolean addToCart(ItemGolusinski item) 
	{
		if (j < myItems.length)
			if (myItems[j] == null)
			{
				myItems[j] = item;
				mySize++;
				j++;
				return true;
			}//if statement
		return false;
	}// addToCart

	/**
	 * This method will loop through every item in the array, ignoring
	 * any null values, and find the most expensive item.
	 * @return maxItem The most expensive item in the array.
	 */
	public ItemGolusinski findMostExpensive() 
	{
		ItemGolusinski maxItem = null;
		if (myItems[0] != null)
		{
			double maxPrice = myItems[0].getPrice();
			maxItem = myItems[0];
			for (int i = 1; i < myItems.length; i++)
				if (myItems[i] != null)
					
					if (myItems[i].getPrice() > maxPrice) 
					{
						maxPrice = myItems[i].getPrice();
						maxItem = myItems[i];
					} // if statement
		}
		return maxItem;
	}// findMostExpensive

	/**
	 * This method will loop through every item in the array, ignoring
	 * any null values, and find the least expensive item.
	 * @return minItem The least expensive item in the array.
	 */
	public ItemGolusinski findLeastExpensive() 
	{
		ItemGolusinski minItem = null;
		if (myItems[0] != null) 
		{
			double minPrice = myItems[0].getPrice();
			minItem = myItems[0];
			for (int i = 1; i < myItems.length; i++)
				if (myItems[i] != null)
					if (myItems[i].getPrice() < minPrice) 
					{
						minPrice = myItems[i].getPrice();
						minItem = myItems[i];
					} // if statement
		}
		return minItem;
	}// findLeastExpensive

	/**
	 * This method will calculate the total amount of all items in the array.
	 * @return total The total cost of all items in the array.
	 */
	public double calcTotal() {
		double total = 0;
		for (int i = 0; i < myItems.length; i++) 
		{
			if (myItems[i] != null) {
				double price = myItems[i].getPrice();
				int quantity = myItems[i].getQuant();
				total += (price * quantity);
			} // if statement
		} // for loop
		return total;
	}// calcTotal

	/**
	 * This printList method will print out a description of each item in the list,
	 * consisting of the name, quantity, and individual price.
	 */
	public void printList() {
		int printCheck = 0;
		for (int i = 0; i < myItems.length; i++) 
		{
			if (myItems[i] != null) {
				System.out.println("Item " + (i + 1) + ": ");
				System.out.println("Name: " + myItems[i].getName());
				System.out.println("Quantity: " + myItems[i].getQuant());
				System.out.println("Individual Price: $" + myItems[i].getPrice());
				printCheck++;
			} // if statement
		} // for loop
		if (printCheck == 0)
			System.out.println("There are no items in the cart.");
	}// printList

	/**
	 * This "extra for experts" challenge will identify the highest priced item in the
	 * cart, and remove it from the cart.
	 * @param shopping The shopping cart (array) of all items the user provides.
	 */
	public void deleteItem(ShoppingCartGolusinski shopping) 
	{
		int maxPosition = 0;
		double maxPrice = 0;
		if (mySize >= 1)
		{
			for (int i = 0; i < myItems.length; i++)
				if (myItems[i] != null)
					if (myItems[i].getPrice() > maxPrice) 
					{
						maxPosition = i;
						maxPrice = myItems[maxPosition].getPrice();
					} // if statement
			myItems[maxPosition] = myItems[mySize - 1];
			myItems[mySize - 1] = null;
			j--;
			mySize--;
			System.out.println("Item successfully deleted!");
		} //if statement
		else
			System.out.println("No items were deleted, as there are no items in the cart.");
	}// deleteItem
}// ShoppingCartGolusinski
