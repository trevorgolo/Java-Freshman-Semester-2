/**
* @author Trevor Golusinski <br>
* Prog 10 <br>
* Due Date and Time: May 17th, 2021 before 9:00 AM <br>
*
* Purpose: The purpose of this program is to simulate a game of "War" or "Battle"
* 			in a quick and efficient manner, to display the end results.<br>
*
* Input: The only input the user will be required to enter is the file name. <br>
*
* Output: The program will output how many cards there were to start, how many plays
* 			were in the game, how many cards each player ended with, and who won. <br>
*
* Certification of Authenticity:
* I certify that this lab is entirely my own work. <br>
 */
public class NodeGolusinski 
{
	/**
	 * An instance variable to hold the data of a given item.
	 */
	private CardGolusinski myData;
	/**
	 * An instance variable to hold the reference to the next node.
	 */
	private NodeGolusinski myNext;

	/**
	 * The null constructor sets the data and next node to null, to identify any errors
	 * that may be present in the code.
	 */
	public NodeGolusinski()
	{
		myData = null;
		myNext = null;
	}//Node null constructor

	/**
	 * The full constructor adds data to a node, while keeping the next reference
	 * as null.
	 * @param newData User-entered data that needs to be saved.
	 */
	public NodeGolusinski(CardGolusinski newData)
	{
		myData = newData;
		myNext = null;
	}//Node full constructor

	/**
	 * This getter method will return the data of a given node.
	 * @return The data of a given node
	 */
	public CardGolusinski getData()
	{
		return myData;
	}//getData

	/**
	 * This setter method will set the data of a given node
	 * @param newData The data that is entered by the user
	 */
	public void setData(CardGolusinski newData)
	{
		myData = newData;
	}//setData

	/**
	 * This getter method will call the next node in the linked list.
	 * @return The next node in the linked list.
	 */
	public NodeGolusinski getNext()
	{
		return myNext;
	}//getNext

	/**
	 * This setter method will set the next node in line in the linked list.
	 * @param newNext The next node in line in the linked list.
	 */
	public void setNext(NodeGolusinski newNext)
	{
		myNext = newNext;
	}//setNext
}//NodeGolusinski
