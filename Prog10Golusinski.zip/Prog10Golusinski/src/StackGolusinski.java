/**
* @author Trevor Golusinski <br>
* Prog 10 <br>
* Due Date and Time: May 17th, 2021 before 9:00 AM <br>
*
* Purpose: The purpose of this program is to simulate a game of "War" or "Battle"
* 			in a quick and efficient manner, to display the end results.<br>
*
* Input: The only input the user will be required to enter is the file name. <br>
*
* Output: The program will output how many cards there were to start, how many plays
* 			were in the game, how many cards each player ended with, and who won. <br>
*
* Certification of Authenticity:
* I certify that this lab is entirely my own work. <br>
 */
public class StackGolusinski {

	/**
	 * An instance variable to keep track of the card at the top of the stack.
	 */
	private NodeGolusinski myTop;
	
	/**
	 * The null constructor sets the top card to null, in order
	 * to identify issues in the program, and to start with a clean slate.
	 */
	public StackGolusinski()
	{
		myTop = null;
	}//stack null constructor
	
	/**
	 * The isEmpty method will return whether or not the stacks are empty, by checking
	 * to see if there is a card at the top of the stack.
	 * @return True or False, depending on whether there are cards in the stack.
	 */
	public boolean isEmpty()
	{
		return (myTop == null);
	}//isEmpty

	/**
	 * The isFull method will return whether or not the stack is full, however,
	 * since nodes and linked lists are being used, the list can never be full.
	 * @return False, since the list can never be full.
	 */
	public boolean isFull()
	{
		return false;
	}//isFull
	
	/**
	 * The push method will "push" a card on top of the stack, adding to the others,
	 * and becoming the myTop card.
	 * @param card The data of the card that is being added to the stack.
	 * @return True after the card was added.
	 */
	public boolean push(CardGolusinski card)
	{
		boolean ans = true;
		NodeGolusinski newCard = null;
		newCard = new NodeGolusinski();
		newCard.setData(card);
		newCard.setNext(myTop);
		myTop = newCard;
		return ans;
	}//push
	
	/**
	 * The pop method will "pop" a card off the top of the stack, and will replace
	 * the myTop card with the next card in line.
	 * @return The data of the card that was popped off.
	 */
	public CardGolusinski pop()
	{
		CardGolusinski ans = null;
		
		if(myTop != null)
		{
			ans = myTop.getData();
			myTop = myTop.getNext();
		}//if
		return ans;
	}//pop
	
	/**
	 * The retrieve method will retrieve the information about the top card.
	 * @return The data of the card, including the value of it, as well as the suit.
	 */
	public CardGolusinski retrieve()
	{
		return myTop.getData();
	}//retrieve
}//StackGolusinski
