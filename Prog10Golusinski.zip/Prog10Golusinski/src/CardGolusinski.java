/**
* @author Trevor Golusinski <br>
* Prog 10 <br>
* Due Date and Time: May 17th, 2021 before 9:00 AM <br>
*
* Purpose: The purpose of this program is to simulate a game of "War" or "Battle"
* 			in a quick and efficient manner, to display the end results.<br>
*
* Input: The only input the user will be required to enter is the file name. <br>
*
* Output: The program will output how many cards there were to start, how many plays
* 			were in the game, how many cards each player ended with, and who won. <br>
*
* Certification of Authenticity:
* I certify that this lab is entirely my own work. <br>
 */
public class CardGolusinski 
{
	/**
	 * An instance variable to hold the suit type of a card.
	 */
	String mySuit;
	
	/**
	 * An instance variable to hold the numeric value of a card (ranging from 2-14).
	 */
	int myValue;
	
	/**
	 * The null constructor will set the suit to EMPTY, and the value to 0, to help
	 * identify errors in the code, and to start with a clean slate.
	 */
	public CardGolusinski()
	{
		mySuit = "EMPTY";
		myValue = 0;
	}//CardGolusinski null constructor
	
	/**
	 * The full constructor will assign a designated suit and value to a new card,
	 * once it receives the appropriate values.
	 * @param newValue The value of a card, given by the file.
	 * @param newSuit The suit of a card, given by the file.
	 */
	public CardGolusinski(int newValue, String newSuit)
	{
		mySuit = newSuit;
		myValue = newValue;
	}//CardGolusinski full constructor
	
	/**
	 * The getSuit method will return the suit classification of the card when requested.
	 * @return The String value of the card's suit.
	 */
	public String getSuit()
	{
		return mySuit;
	}//getSuit
	
	/**
	 * The setSuit method will assign a new String to the suit of a given card.
	 * @param newSuit The new classification of suit that was assigned to the card.
	 */
	public void setSuit(String newSuit)
	{
		mySuit = newSuit;
	}//setSuit
	
	/**
	 * The getValue method will return the value of a card when requested.
	 * @return The numeric value of a card, ranging from 2-14.
	 */
	public int getValue()
	{
		return myValue;
	}//getValue
	
	/**
	 * The setValue method will assign a new integer value to a given card.
	 * @param newValue The new value of a given card.
	 */
	public void setValue(int newValue)
	{
		myValue = newValue;
	}//setValue
}//CardGolusinski
