import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
* @author Trevor Golusinski <br>
* Prog 10 <br>
* Due Date and Time: May 17th, 2021 before 9:00 AM <br>
*
* Purpose: The purpose of this program is to simulate a game of "War" or "Battle"
* 			in a quick and efficient manner, to display the end results.<br>
*
* Input: The only input the user will be required to enter is the file name. <br>
*
* Output: The program will output how many cards there were to start, how many plays
* 			were in the game, how many cards each player ended with, and who won. <br>
*
* Certification of Authenticity:
* I certify that this lab is entirely my own work. <br>
 */
public class BattleDemoGolusinski 
{
	/**
	 * Declaration statement to initialize a scanner to intake user input.
	 */
	static Scanner keyboard = new Scanner(System.in);
	
	/**
	 * The main method is where majority of the method calling, and regrouping
	 * will occur.
	 * @param args An array of Strings that are used by the main method by default.
	 */
	public static void main(String[] args) 
	{
		int numTurns = 0;
		int gameCards = 0;
		int win = 0;
		//Initialize the main card stacks
		StackGolusinski player1 = new StackGolusinski();
		StackGolusinski player2 = new StackGolusinski();
		
		//Initialize the discard stacks
		StackGolusinski player1Discard = new StackGolusinski();
		StackGolusinski player2Discard = new StackGolusinski();
		
		//Initialize the individual card holders
		CardGolusinski p1Card;
		CardGolusinski p2Card;
	
		//Deal the cards
		gameCards = deal(player1, player2);
	
		//Count the cards
		int player1Count = countCards(player1);
		int player2Count = countCards(player2);
		
		//Begin the game
		while ((player1Count != 0) && (player2Count != 0) && (numTurns < 1000))
		{
			win = 0;
			//Pick a card from each stack
			p1Card = play(player1);
			p2Card = play(player2);
			//Compare the cards
			win = compare(p1Card,p2Card);
			//Give the appropriate winner the cards, or put them back if it is a complete tie.
			winPlay(player1, player2, win, player1Discard, player2Discard, p1Card, p2Card);
			//Put the cards back in their respective decks
			copy(player1, player1Discard);
			copy(player2, player2Discard);
			//Recount the amount of cards each player has
			player1Count = countCards(player1);
			player2Count = countCards(player2);
			//Increase the number of turns there have been
			numTurns++;
		}//while
		//Count the final amount of cards
		int cards1 = countCards(player1);
		int cards2 = countCards(player2);
		
		if(cards1 > cards2)
			win = 1; //Player 1 wins
		else if (cards1 < cards2)
			win = 2; //Player 2 wins
		else
			win = 0; // It is a tie
		
		//Print out the results
		printResults(gameCards, numTurns, win, player1Count, player2Count);
	}//main

	/**
	 * The deal method will evenly distribute the cards amongst the player's decks.
	 * @param p1 Player 1's stack of cards
	 * @param p2 Player 2's stack of cards
	 * @return The total amount of cards in the deck
	 */
	public static int deal(StackGolusinski p1, StackGolusinski p2)
	{
		String fileName = null;
		String suit = "";
		int value = 0;
		boolean read = false;
		CardGolusinski card = new CardGolusinski(value, suit);
		int turn = 1; //Which player's turn it is when dealing cards
		int cards = 0; //The amount of cards in play
		do 
	    {
	    	//Consistently loop through the code until the user enters a valid file.
	    	System.out.print("Please enter the file name: ");
	    	fileName = keyboard.next();
		    File mainFile = new File(fileName);
	    	try
		    {
		    	Scanner input = new Scanner(mainFile);
			    while (input.hasNext() != false)
			    {
			    	//Get their values
			    	value = input.nextInt();
			    	suit = input.next();
			    	//Initialize the card
			    	card = new CardGolusinski(value, suit);
			    	cards++;
			    	//Add the card to the appropriate stack
			    	if(turn == 1) //It is Player 1's turn to get cards
			    	{
			    		p1.push(card);
			    		turn = 2;
			    	}//if
			    	else //It is player 2's turn to get cards
			    	{
			    		p2.push(card);
			    		turn = 1;
			    	}//else
			    }//while 
			    //while (input.hasNext());
			    input.close();
			    System.out.println("Items in file successfully added to stack!");
			    read = true;
		    }//try
		    catch(FileNotFoundException ex)
		    {
		    	System.out.println("Could not find file: " + mainFile.getAbsolutePath()); 
		    }//catch: file not found
		    catch(InputMismatchException ex)
		    {
		    	System.out.println("Type mismatch for the number I just tried to read.");
		        System.out.println(ex.getMessage());
		    }//catch: type mismatch
		    catch(NumberFormatException ex)
		    {
		    	System.out.println("Failed to convert String text into an integer value.");
		    	System.out.println(ex.getMessage());
		    }//catch: converting string to integer
		    catch(NullPointerException ex)
		    {
		    	System.out.println("Null pointer exception.");
		    	System.out.println(ex.getMessage());
		    }//catch: value is null
		    catch(Exception ex)
		    {	    	
		    	System.out.println("Something went wrong");
		    	ex.printStackTrace();
		    }//catch: other error
	    }//Read file loop
	    while (read == false);
		return cards;
	}//deal
	
	/**
	 * The play method calls the retrieve method in the StackGolusinski class, to
	 * obtain the numerical values and suits of the cards.
	 * @param player The given player's stack of cards.
	 * @return The suit and numerical value of the top card.
	 */
	public static CardGolusinski play(StackGolusinski player)
	{
		return player.retrieve();
	}//play
	
	/**
	 * The compare method will compare the two cards, deciding which one wins, if at all.
	 * @param p1 The stack of Player 1's cards.
	 * @param p2 The stack of Player 2's cards
	 * @return 1 or 2, depending on the winner of the duel, or 0 if there is a full tie
	 */
	public static int compare(CardGolusinski p1, CardGolusinski p2)
	{
		int winner = 0;
		//Get their values
		int p1Val = p1.getValue();
		int p2Val = p2.getValue();
		//Get their suits
		String p1Suit = p1.getSuit();
		String p2Suit = p2.getSuit();
		//Compare the values
		if(p1Val > p2Val) //Player 1 Wins
			winner = 1;
		else if (p1Val < p2Val) //Player 2 Wins
			winner = 2;
		else if (p1Val == p2Val) //If their values are the same, compare suits
		{
			switch (p1Suit)
			{
			case "Spades":
				if(p2Suit == "Spades")
					winner = 0;
				else if(p2Suit == "Hearts")
					winner = 1;
				else if(p2Suit == "Diamonds")
					winner = 1;
				else if(p2Suit == "Clubs")
					winner = 1;
				break;
			case "Hearts":
				if(p2Suit == "Spades")
					winner = 2;
				else if(p2Suit == "Hearts")
					winner = 0;
				else if(p2Suit == "Diamonds")
					winner = 1;
				else if(p2Suit == "Clubs")
					winner = 1;
				break;
			case "Diamonds":
				if(p2Suit == "Spades")
					winner = 2;
				else if(p2Suit == "Hearts")
					winner = 2;
				else if(p2Suit == "Diamonds")
					winner = 0;
				else if(p2Suit == "Clubs")
					winner = 1;
				break;
			case "Clubs":
				if(p2Suit == "Spades")
					winner = 2;
				else if(p2Suit == "Hearts")
					winner = 2;
				else if(p2Suit == "Diamonds")
					winner = 2;
				else if(p2Suit == "Clubs")
					winner = 0;
				break;
			default: //In the event that a glitch occurs, this will catch it
				System.out.println("An error occurred.");
				break;
			}//switch
		}//else if
		return winner;
	}//compare
	
	/**
	 * The winPlay method will take the appropriate action from the compare method,
	 * and give the winner both cards, or give both players their respective cards back
	 * if there was a full tie.
	 * @param p1 Player 1's stack of cards
	 * @param p2 Player 2's stack of cards
	 * @param winner The numerical value of the winner (0, 1, or 2)
	 * @param p1Discard Player 1's discard pile
	 * @param p2Discard Player 2's discard pile
	 * @param player1Card Player 1's card that was used
	 * @param player2Card Player 2's card that was used
	 */
	public static void winPlay(StackGolusinski p1, StackGolusinski p2, int winner, StackGolusinski p1Discard, StackGolusinski p2Discard, CardGolusinski player1Card, CardGolusinski player2Card)
	{
		if(winner == 0) //If there was a tie, give then both their cards back
		{
			p1Discard.push(player1Card);
			p1.pop();
			
			p2Discard.push(player2Card);
			p2.pop();
		}//if
		else if(winner == 1) //If Player 1 won, give them their card first, then Player 2's card
		{
			p1Discard.push(player1Card);
			p1Discard.push(player2Card);
			p1.pop();
			p2.pop();
		}//if
		else if(winner == 2) //If Player 2 won, give them their card first, then Player 1's card
		{
			p2Discard.push(player2Card);
			p2Discard.push(player1Card);
			p2.pop();
			p1.pop();
		}//if
	}//winPlay
	
	/**
	 * The copy method will return the player's cards from their discard pile into
	 * their playing pile, to be used again.
	 * @param player The player's stack of cards
	 * @param playerDiscard The player's discard pile
	 */
	public static void copy(StackGolusinski player, StackGolusinski playerDiscard)
	{
		CardGolusinski value = null;
		StackGolusinski temp = new StackGolusinski();
		
		while(!playerDiscard.isEmpty()) //Move all of the cards in the discard pile into the temp pile
		{
			value = playerDiscard.pop();
			temp.push(value);
		}//while
		while(!temp.isEmpty()) //Move all of the cards in the temp pile to the play pile
		{
			value = temp.pop();
			player.push(value);
		}//while
	}//copy
	
	/**
	 * The countCards method will count the amount of cards a given player has in their hand
	 * @param player The player's stack of cards
	 * @return The number of cards a player has
	 */
	public static int countCards(StackGolusinski player)
	{
		int ans = 0;
		CardGolusinski value = null;
		StackGolusinski temp = new StackGolusinski();
		while(!player.isEmpty()) //Move all of the cards in the player's pile into a temp pile, and count each one
		{
			value = player.pop();
			temp.push(value);
			ans++;
		}//while
		while(!temp.isEmpty()) //Move all of the cards in the temp pile back into the player's pile
		{
			player.push(temp.pop());
		}//while
		return ans;
	}//countCards
	
	/**
	 * The printResults method will print out the final result of the game.
	 * @param totalCards The amount of cards that were in play.
	 * @param plays The amount of rounds that the game went on.
	 * @param winner The winner of the game, or whether it was a tie.
	 * @param p1Cards The final number of cards that Player 1 ended with.
	 * @param p2Cards The final number of cards that Player 2 ended with.
	 */
	public static void printResults(int totalCards, int plays, int winner, int p1Cards, int p2Cards)
	{
		System.out.println("The game started with " + totalCards + " card(s)."
				+ "\nThere were " + plays + " plays in the game.");
		if((winner == 1) || (winner == 2))
			System.out.println("The game ended with a clear winner.");
		else
			System.out.println("There was no clear winner.");
		System.out.println("Player 1 ended with " + p1Cards + " card(s).");
		System.out.println("Player 2 ended with " + p2Cards + " card(s).");
		if(winner == 1)
			System.out.println("The winner was Player 1.");
		else if (winner == 2)
			System.out.println("The winner was Player 2.");
		else
			System.out.println("The game ended in a tie.");
		keyboard.close();
	}//printResults
}//BattleDemoGolusinski
