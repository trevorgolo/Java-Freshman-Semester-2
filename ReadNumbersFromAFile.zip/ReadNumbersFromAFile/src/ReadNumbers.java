// Use import to gain access to Java utility classes for file input/output.
import java.io.*;
import java.util.*;

public class ReadNumbers
{
	// Create a new keyboard Scanner object.
  static Scanner keyboard = new Scanner(System.in);
    
  public static void main(String[] args)
  {   
	String fileName = null;
	int numValues = 0;
    int num = 0;
    int sum = 0;
    
    //ask the user for the path and name to the file
    System.out.print("Enter a filename: ");
    fileName = keyboard.next();    
    
    //create the reference to the file, declared up here because of the "catch"
    File inputFile = new File(fileName);

    //try to open and use the file, if possible
    try
    {
      
      //Create a second Scanner object, this one for reading from the file
      Scanner input = new Scanner(inputFile);
      
      // Read first line of the file to find out how many numbers will follow.
      numValues = input.nextInt();
    
      // An exception is thrown if you try to read past the end-of-file.
      for(int i = 0; i < numValues; i++)
      {
        // Read next line.
        num = input.nextInt();
        sum = sum + num;
      }//for i
      
      System.out.println("The sum is " + sum);
      
      // Even closing a file is "risky" and must be inside a try.
      input.close();
      keyboard.close();
    }//try
    
    // This example shows how to have different "catchers" each specialized to
    // handle a specific kind of problem.
    // The advantage is that your error messages or cleanup can be specialized
    // so that it best handles each kind of problem.

    catch(FileNotFoundException ex)
    {
      System.out.println("Failed to find file: " + inputFile.getAbsolutePath()); 
    }//catch
    catch(InputMismatchException ex)
    {
    	System.out.println("Type mismatch for the number I just tried to read.");
        System.out.println(ex.getMessage());
    }
    catch(NumberFormatException ex)
    {
      System.out.println("Failed to convert String text into an integer value.");
      System.out.println(ex.getMessage());
    }//catch
    catch(NullPointerException ex)
    {
      System.out.println("Null pointer exception.");
      System.out.println(ex.getMessage());
    }//catch
    catch(Exception ex)
    {
      // Like an "else" catch(Exception should come last as the catchall.
    	System.out.println("Something went wrong");
      ex.printStackTrace();
    }//catch
  }//main
}//ReadNumbers