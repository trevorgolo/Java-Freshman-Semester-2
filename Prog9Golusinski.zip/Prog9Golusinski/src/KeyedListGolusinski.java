/**
* @author Trevor Golusinski <br>
* Prog 9 <br>
* Due Date and Time: May 6th, 2021 before 9:00 AM <br>
*
* Purpose: The purpose of this program is to assist a user in shopping, by keeping
*			track of their items, costs, and names of items, with the initial
*			items being collected from a file. It will also sort the items in
*			the list via their names. <br>
*
* Input: The user will input a file name, then input their menu choice, and will 
* 			follow the on-screen instructions that are displayed after each choice. <br>
*
* Output: The program will output a response to every user input, and will display
*			information such as number of items, cost of each item, item names,
*			etc, all based on user input. <br>
*
* Certification of Authenticity:
* I certify that this lab is entirely my own work. <br>
 */
public class KeyedListGolusinski 
{
	/**
	 * Instance variable to hold the size of the array.
	 */
	int mySize;
	
	/**
	 * Instance variable to hold the head of the linked list.
	 */
	private NodeGolusinski myHead;
	
	/**
	 * The null constructor that will initialize the size of the list, as well as
	 * the size, and set all items in the list to null or 0.
	 */
	public KeyedListGolusinski()
	{
		myHead = null;
		mySize = 0;
	}//KeyedListGolusinski
	
	/**
	 * The clear() method will set the size of the list equal to 0, effectively clearing
	 * the list of all elements.
	 */
	public void clear()
	{
		mySize = 0;
	}//clear
	
	/**
	 * The findIndex() helper method will search through the entire list of items 
	 * until either it finds the item, or it reaches the end of the list.
	 * @param keyValue - The name of the item that the user wishes to find.
	 * @return Either a negative number, indicating that the item does not exist,
	 * or the index location of the item.
	 */
	private int findIndex(String keyValue)
	{
		int index = -1;
		ItemGolusinski filler;
		String name;
		NodeGolusinski curr = myHead;
		for (int i = 0; i < mySize; i++)
		{
			filler = curr.getData();
			name = filler.getName();
			if (name.equalsIgnoreCase(keyValue))
				index = i;
			curr = curr.getNext();
		}//for
		return index;
	}//findIndex
	
	/**
	 * The add() method will add an item to the array, ensuring that it is placed
	 * correctly, in alphabetical order. It will shift over any items that are
	 * ahead of the item's designated spot, in order to make space.
	 * @param product - The item information that the user entered.
	 * @return True or False, indicating whether the item was successfully added or not.
	 */
	public boolean add(ItemGolusinski product)
	{
		//set up variables
		boolean found = false;
		boolean added = false;
		NodeGolusinski curr = myHead;
		NodeGolusinski prev = null;
		NodeGolusinski newOne = new NodeGolusinski(product);
		ItemGolusinski filler;
		String name = "";
		
		//find where it goes
		while ((curr != null) && (!found))
		{
			filler = curr.getData();
			name = filler.getName();
			if (name.compareToIgnoreCase(product.getName()) > 0)
				found = true;
			else
			{
				prev = curr;
				curr = curr.getNext();
			}//else
		}//while
		
		//put it where it belongs in the list
		if (findIndex(product.getName()) == -1)
		{
			newOne.setNext(curr);
			if (prev == null)
			{
				myHead = newOne;
				added = true;
			}//if
			else
			{
				prev.setNext(newOne);
				added = true;
			}//else
			mySize++;
		}//if
		return added;
	}//add
	
	/**
	 * The remove() method will remove an item from the list, and shift all items
	 * ahead of it backward, such that they fill in the gaps.
	 * @param keyValue - The name of the item that the user wishes to remove.
	 * @return True or False, indicating whether the item was successfully removed or not.
	 */
	public boolean remove(String keyValue)
	{
		//set up variables
		boolean found = false;
		NodeGolusinski curr = myHead;
		NodeGolusinski prev = null;
		ItemGolusinski filler = curr.getData();
		
		//find it
		while ((curr != null) && (!found))
		{
			filler = curr.getData();
			String name = filler.getName();
			//if (name == keyValue)
			if(name.compareToIgnoreCase(keyValue) == 0)
				found = true;
			else
			{
				prev = curr;
				curr = curr.getNext();
			}//else
		}//while
		
		//modify the list
		if(found)
		{
			if (prev == null)
			{
				myHead = curr.getNext();
				mySize--;
			}//if
			else
			{
				prev.setNext(curr.getNext());
				mySize--;
			}//else
		}//if statement
			return found;
	}//remove
	
	/**
	 * The retrieve() method will first ensure that the item in question exists, and
	 * if so, it will return details on the item.
	 * @param keyValue - The item name that the user wishes to find.
	 * @return Details on the item, or null if the item does not exist.
	 */
	public ItemGolusinski retrieve(String keyValue)
	{
		NodeGolusinski curr = myHead;
		int count = 0;
		ItemGolusinski ans = null;
		int location = findIndex(keyValue);
		if (location != -1)
			for (count = 0; count < location; count++)
			{
				curr = curr.getNext();
				ans = curr.getData();
			}//for loop
		return ans;
	}//retrieve
	
	/**
	 * The isEmpty() method will check if mySize is greater than 0, checking whether
	 * there are items in the list.
	 * @return True or False, indicating whether the array is empty or not.
	 */
	public boolean isEmpty()
	{
		boolean ans = true;
		if (mySize > 1)
			ans = false;
		return ans;
	}//isEmpty
	
	/**
	 * The isFull() method will always return false, as the list cannot be full.
	 * @return True or False, indicating whether the array is full or not.
	 */
	public boolean isFull()
	{
		return false;
	}//isFull
	
	/**
	 * The print() method will print out details on every item in the list, including
	 * name, quantity, and individual price. If there are no items, it will inform
	 * the user that the list is empty.
	 */
	public void print()
	{
		NodeGolusinski curr = myHead;
		int printCheck = 0;
		for (int i = 0; i < mySize; i++) 
		{	
			System.out.println("Item " + (i + 1) + ": ");
			System.out.println(curr.getData());
			printCheck++;
			curr = curr.getNext();
		} // for loop
		if (printCheck == 0)
			System.out.println("There are no items in the cart.");
	}//print
	
	/**
	 * The getCount() method will calculate the total number of items in the cart.
	 * @return The sum of the quantities of each item.
	 */
	public int getCount()
	{
		NodeGolusinski curr = myHead;
		ItemGolusinski filler;
		int count;
		int sum = 0;
		
		for (int i = 0; i < mySize; i++)
		{
			filler = curr.getData();
			count = filler.getQuant();
			sum += count;
			curr = curr.getNext();
		}//for
		return sum;
	}//getCount
	
	/**
	 * The calcTotal() method will calculate the total cost of all items in the cart,
	 * by multiplying the cost and the quantities of each item.
	 * @return The total cost of all items in the cart
	 */
	public double calcTotal()
	{
		NodeGolusinski curr = myHead;
		ItemGolusinski filler;
		double total = 0;
		double sum = 0;
		for (int i = 0; i < mySize; i++)
		{
			filler = curr.getData();
			sum = filler.getPrice() * filler.getQuant();
			total += sum;
			curr = curr.getNext();
		}//for
		return total;
	}//calcTotal
}//KeyedListGolusinski
