import java.util.*;

public class IOExample 
{
    //define the keyboard for the entire project
	static Scanner keyboard = new Scanner(System.in);
	public static void main(String[] args) 
	{
		//Declare variables
		String name;
		int age = 0;
		int older = 0;
		double[][] happy = new double[4][3];
		
		System.out.println(happy[0][1]);
		
		//Greet the user and describe the program.
		System.out.println("Welcome to the age program.");
		System.out.println("This program will ask your name and age, then output some info.");
		System.out.println();
		
		//Set the input
		System.out.println("Enter your name: ");
		name = keyboard.next();
		
		System.out.print("Enter your age: ");
		age = keyboard.nextInt();
		
		//Calculate older age
		older = age + 10;
		
		//Output the results
		System.out.println("Hello, " + name + ".");
		System.out.println("In ten years you will be " + older + " years old.");
		
		System.out.println("\nThanks! Goodbye!");
		keyboard.close();
	} //main

} //IOExample
