/**
// @author Trevor Golusinski <br>
// Prog 5
// Due Date and Time: April 5th, 2021 before 9:00 AM
//
// Purpose: This program will draw steps out of whichever character the user provides.
// 			The user also has full control of how many lines and the width of them.
//
// Input: The user will input their menu choice, and can also input a desired width,
//			desired number of steps, and/or a fill style
//
// Output: The program will output imagery of the steps, responses to the user's
//			menu choices, as well as a hello and goodbye greeting/parting.
//
// Certification of Authenticity: I certify that this lab is entirely my own work.
 * 
 */
import java.util.*;
/**
 *This is the class definition for StepsDemo
 */
public class StepsDemoGolusinski {

	
	static Scanner keyboard = new Scanner(System.in);
	//This is the main class, where all of the user input will be handled, as 
	//well as the calls to other methods and classes.
	public static void main(String[] args) 
	{
		StepsGolusinski step = new StepsGolusinski(2, 5, '*');
		int stepWidth = 2;
		int numOfSteps = 5;
		char fillStyle = '*';
		String fakeMenuInput;
		char menuInput;
		String fakeFillStyle;
		
		System.out.println("Welcome! This program will generate steps based on your" +
				" preference of width, number of steps, and fill style!");
		System.out.println("Please choose an option from the following menu:" +
				"\nW: Assign the Step Width" +
				"\nN: Assign the Number of Steps" +
				"\nF: Assign the Fill Style" +
				"\nA: Calculate the Area" +
				"\nT: Text Description of the Steps" +
				"\nD: Draw the Steps" +
				"\nX: Draw Thick Steps" +
				"\nQ: Quit");
		do 
		{
			do 
			{
				System.out.print("Please select an item: ");
				fakeMenuInput = keyboard.next();
				fakeMenuInput = fakeMenuInput.toLowerCase();
				menuInput = fakeMenuInput.charAt(0);
			}//do loop
			while ((menuInput != 'w') && (menuInput != 'n') && (menuInput != 'f') && (menuInput != 'a') && (menuInput != 't') && (menuInput != 'd') && (menuInput != 'x') && (menuInput != 'q'));
			
			if (menuInput == 'w') 
			{
				System.out.print("Please enter the new step width: ");
				stepWidth = keyboard.nextInt();
				step.setStepWidth(stepWidth);
			}//w if statement
			
			else if (menuInput == 'n')
			{
				System.out.print("Please enter the new number of steps: ");
				numOfSteps = keyboard.nextInt();
				step.setNumSteps(numOfSteps);
			}//n if statement
			
			else if (menuInput == 'f')
			{
				System.out.print("Please enter the new fill style: ");
				fakeFillStyle = keyboard.next();
				fillStyle = fakeFillStyle.charAt(0);
				step.setFillStyle(fillStyle);
			}//f if statement
			
			else if (menuInput == 'a')
			{
				System.out.println("The area is: " + step.calcArea());
			}//a if statement
			
			else if (menuInput == 't')
			{
				System.out.print(step.toString());
				System.out.println("The area of the steps is " + step.calcArea());
			}//t if statement
			
			else if (menuInput == 'd')
			{
				step.drawSteps();
			}//d if statement
			
			else if (menuInput == 'x')
			{
				step.drawThickSteps();
			}//x if statement
		}//huge do loop
		while (menuInput != 'q');
		
		System.out.println("Thank you for using this program! Goodbye!");
		keyboard.close();
	}//main
}//StepsDemoGolusinski