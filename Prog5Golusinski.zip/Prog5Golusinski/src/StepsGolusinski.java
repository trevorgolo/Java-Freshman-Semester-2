/**
// @author Trevor Golusinski <br>
// Prog 5 <br>
// Due Date and Time: April 5th, 2021 before 9:00 AM <br>
//
// Purpose: This program will draw steps out of whichever character the user provides.
// 			The user also has full control of how many lines and the width of them. <br>
//
// Input: The user will input their menu choice, and can also input a desired width,
//			desired number of steps, and/or a fill style <br>
//
// Output: The program will output imagery of the steps, responses to the user's
//			menu choices, as well as a hello and goodbye greeting/parting. <br>
//
// Certification of Authenticity:
// I certify that this lab is entirely my own work. <br>
 * 
 */
public class StepsGolusinski 
{
/**
 * Instance variable to for the width of the steps.
 */
int myStepWidth;
/**
 * Instance variable for the number of steps.
 */
int myNumSteps;
/**
 * Instance variable for the type of fill style the user desires.
 */
char myFillStyle;

/**
* The null constructor for Steps
 * 
 */
public StepsGolusinski()
{
	myStepWidth = 0;
	myNumSteps = 0;
	myFillStyle = '-';
}//StepsGolusinski constructor

/**
 * The default constructor for the demo.
 * @param newStepWidth
 * @param newNumSteps
 * @param newFillStyle
 */
public StepsGolusinski(int newStepWidth, int newNumSteps, char newFillStyle)
{
	myStepWidth = newStepWidth;
	myNumSteps = newNumSteps;
	myFillStyle = newFillStyle;
}//StepsGolusinski constructor 
/**
 * This get method, getStepWidth, will get the width of the steps, and return it to main.

 * @return myStepWidth, the current width of the steps.
 */
public int getStepWidth()
{
	return myStepWidth;
}//getStepWidth

//This set method, setStepWidth, will set the user's width input in place of 
//the currently used width.
public void setStepWidth(int newStepWidth)
{
	myStepWidth = newStepWidth;
}//setStepWidth

//This get method, getNumSteps, will get the width of the steps, and return it to main.
public int getNumSteps()
{
	return myNumSteps;
}//getNumSteps

//This set method, setNumSteps, will set the user's number of steps in place of the
//currently used number of steps.
public void setNumSteps(int newNumSteps)
{
	myNumSteps = newNumSteps;
}//setNumSteps

//This get method, getFillStyle, will get the currently used fill style, and return
//it to main.
public char getFillStyle()
{
	return myFillStyle;
}//getFillSteps

//This set method, setFillStyle, will set the user's desired fill style in place of
//the currently used fill style.
public void setFillStyle(char newFillStyle)
{
	myFillStyle = newFillStyle;
}//setFillStyle

//This method, calcArea, will calculate the total number of characters used in the
//step imagery.
public int calcArea()
{
	int total = 0;
	for (int i = 1; i <= myNumSteps + 1; i++)
	{
		total = total + (myStepWidth * i);
	}//for loop
	return total;
}//calcArea

//This method, drawSteps, will draw out the step imagery.
public void drawSteps()
{
	for (int a = 1; a <= myNumSteps; a++)
	{
		for (int i = 1; i <= myStepWidth * a; i++)
		{
			System.out.print(myFillStyle);
		}//width for loop
		System.out.println();
	}//numSteps for loop
}//drawSteps

//This method, toString, will print out the step width, number of steps, and fill style
//that is being used in the program.
public String toString()
{
	String ans = "Step Width: " + myStepWidth + "\n";
	ans += "Number of Steps: " + myNumSteps + "\n";
	ans += "Fill Style: " + myFillStyle + "\n";
	return ans;
}//toString

//This bonus method, drawThickSteps, will print out a thicker version of the steps,
//with the thickness depending on the step width.
public void drawThickSteps()
{
	for (int a = 1; a <= myNumSteps; a++)
	{
		for (int b = 0; b < myStepWidth; b++)
		{
			for (int i = 1; i <= myStepWidth * a; i++)
			{
				System.out.print(myFillStyle);
			}//i for loop
			System.out.println();
		}//b for loop
	}//a for loop
}//drawThickSteps
}//StepsGolusinski big class