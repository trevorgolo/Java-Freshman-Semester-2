//
// Trevor Golusinski
// Prog 1
// Due Monday, March 1st, 2021 before 9:00 AM
// 
// Purpose: This program will ask the user to enter the amount of money they want to pay, and it will then calculate the most efficient
// 			number of dollar bills and/or coins to do so.
// 
// Input: Amount of money.
// 
// Output: Combination of dollars and cents that can be used to pay, total number of dollars and bills.
// 
// Certification of Authenticity:
// 		I certify that this lab is my own work, but I discussed it with Professor Schwartz in class.
 //
import java.util.*;

public class ChangeMakerGolusinski 
{

	//Declares the keyboard for the project.
	static Scanner keyboard = new Scanner(System.in);
	
	//This method will calculate the entirety of the program, and will display the results when finished.
	public static void main(String[] args) 
	{
		//Declares all of the variables that will be used in the project.
		int amount = 0;
		int originalAmount = 0;
		int twenties = 0;
		int tens = 0;
		int fives = 0;
		int ones = 0;
		int quarters = 0;
		int dimes = 0;
		int nickels = 0;
		int pennies = 0;
		int totalBills = 0;
		int totalCoins = 0;
		
		//Greets the user and describes what the program does.
		System.out.println("Welcome to the Change Maker system!");
		System.out.println("Please enter a whole number.");
		System.out.println("I will output a combination of bills and coins");
		System.out.println("that equals that amount of money.");
		
		//Obtains user input.
		System.out.print("\nEnter amount of money to be changed: ");
		amount = keyboard.nextInt();
		
		//Calculates money output, cycling through every option.
		originalAmount = amount;
		twenties = amount / 2000;
		amount = amount % 2000;
		tens = amount / 1000;
		amount = amount % 1000;
		fives = amount / 500;
		amount = amount % 500;
		ones = amount / 100;
		amount = amount % 100;
		quarters = amount / 25;
		amount = amount % 25;
		dimes = amount / 10;
		amount = amount % 10;
		nickels = amount / 5;
		amount = amount % 5;
		pennies = amount;
		
		//Outputs the results, checking if each one has the value of 1.
		System.out.println("");
		System.out.println(originalAmount + " can be given as:");
		System.out.println("Bills:");
		//Twenties
		if (twenties != 1)
			System.out.println(twenties + " twenties");
		else
			System.out.println(twenties + " twenty");
		//Tens
		if (tens != 1)
			System.out.println(tens + " tens");
		else
			System.out.println(tens + " ten");
		//Fives
		if (fives != 1)
			System.out.println(fives + " fives");
		else
			System.out.println(fives + " five");
		//Ones
		if (ones != 1)
			System.out.println(ones + " ones");
		else
			System.out.println(ones + " one");
		System.out.println("\nCoins:");
		//Quarters
		if (quarters != 1)
			System.out.println(quarters + " quarters");
		else
			System.out.println(quarters + " quarter");
		//Dimes
		if (dimes != 1)
			System.out.println(dimes + " dimes");
		else
			System.out.println(dimes + " dime");
		//Nickels
		if (nickels != 1)
			System.out.println(nickels + " nickels");
		else
			System.out.println(nickels + " nickel");
		//Pennies
		if (pennies != 1)
			System.out.println(pennies + " pennies");
		else
			System.out.println(pennies + " penny");
		
		//Prints the total number of bills and coins needed.
		totalBills = twenties + tens + fives + ones;
		totalCoins = quarters + dimes + nickels + pennies;
		//Bills
		System.out.println("");
		if (totalBills != 1)
			System.out.println("You will need " + totalBills + " bills.");
		else
			System.out.println("You will need " + totalBills + " bill.");
		//Coins
		if (totalCoins != 1)
			System.out.println("You will need " + totalCoins + " coins.");
		else 
			System.out.println("You will need " + totalCoins + " coin.");
		
		//Bids farewell to the user and closes the scanner.
		System.out.println("\nThank you! Goodbye.");
		keyboard.close();
		

	} //main

} //ChangeMakerGolusinski
