//
// Trevor Golusinski
// Prog 2 Resubmission
// Due Date and Time: March 15, 2021 before 9:00 AM
//
// Purpose: This program will calculate and display a taxpayer's
//			number, filing status, taxable income, tax rate, and
//			tax amount owed.
//
// Input: The user will input their taxpayer ID, filing status,
//			gross income, and number of exemptions, in that order.
//
// Output: The program will output the taxpayer ID, filing status,
//			taxable income, tax rate, and tax amount owed.
//
// Certification of Authenticity:
// I certify that this lab is entirely my own work.

import java.util.*;

public class TaxesGolusinski {
	static Scanner keyboard = new Scanner(System.in);

	public static void main(String[] args) {
		int id = 1;
		String fakeStatus;
		char realStatus = 0;
		double grossIncome = 0;
		int exemptions = 0;
		double taxableIncome = 0;
		double taxRate = 0;
		double totalTax = 0;
		int numOfTaxpayers = 0;
		double highestTax = 0;
		int highestTaxID = 0;
		double overallTax = 0;
		double averageTax = 0;
		// Intro
		System.out.println("Hello! This program will calculate " + "your taxes owed!");

		// Taxpayer ID
		System.out.print("Please enter your taxpayer ID (or 0 to quit): ");
		id = keyboard.nextInt();

		while (id != 0) {
			// Filing Status
			realStatus = 0;
			System.out.print("Please enter your filing status " + "\nI for Individual"
					+ "\nM for Married filing Jointly" + "\nH for Head of Household" + "\nYour status: ");
			do {
				fakeStatus = keyboard.next();
				fakeStatus = fakeStatus.toLowerCase();
				realStatus = fakeStatus.charAt(0);
				switch (realStatus) {
				case 'i':
					break;
				case 'm':
					break;
				case 'h':
					break;
				default:
					System.out.print("Unable to read input. Please try again: ");
				} // status switch loop
			} // status do loop
			while ((realStatus != 'i') && (realStatus != 'm') && (realStatus != 'h'));

			// Gross Income
			System.out.print("Please enter your gross income: ");
			grossIncome = keyboard.nextDouble();

			// Number of Exemptions
			do {
				System.out.print("Please enter your number of exemptions (Maximum of 10): ");
				exemptions = keyboard.nextInt();
			} // exemptions do loop
			while ((exemptions < 0) || (exemptions > 10));

			// Taxable Income
			taxableIncome = (grossIncome - 2275) - (exemptions * 1500);

			// Tax Rate
			switch (realStatus) {
			case 'i':
				if (taxableIncome < 15000) {
					taxRate = 0.13;
					break;
				} // less than 15000 taxable income individual
				else if (taxableIncome <= 78000) {
					taxRate = 0.21;
					break;
				} // 78000 or less taxable income individual
				else if (taxableIncome > 78000) {
					taxRate = 0.3;
					break;
				} // greater than 78000 taxable income individual
			case 'm':
				if (taxableIncome < 20000) {
					taxRate = 0.17;
					break;
				} // less than 20,000 taxable income married
				else if (taxableIncome <= 90000) {
					taxRate = 0.24;
					break;
				} // 90,000 or less taxable income married
				else if (taxableIncome > 90000) {
					taxRate = 0.35;
					break;
				} // greater than 90,000 taxable income married
			case 'h':
				if (taxableIncome < 24000) {
					taxRate = 0.16;
					break;
				} // less than 24,000 taxable income head
				else if (taxableIncome <= 85000) {
					taxRate = 0.27;
					break;
				} // 85,000 or less taxable income head
				else if (taxableIncome > 85000) {
					taxRate = 0.38;
					break;
				} // greater than 85,000 taxable income head
			}// Realstatus switch statement

			// Total Tax Due
			totalTax = taxableIncome * taxRate;
			if (totalTax > 0) {
				// System.out.printf("Your total is $%1.2f", totalTax);
				System.out.printf("Taxpayer ID " + id + " owes $%1.2f", totalTax);
			} // If tax is above $0 if statement
			else {
				System.out.println("Taxpayer ID " + id + " does not owe any taxes.");
			} // No taxes if statement

			// Overall calculations (inside loop)
			numOfTaxpayers++;
			if (totalTax > highestTax) {
				highestTax = totalTax;
				highestTaxID = id;
				System.out.println("You have paid the highest amount in taxes so far, at " + highestTax);
			} // highestTax if statement
			overallTax = overallTax + totalTax;
			System.out.println("The total amount of taxes that have been paid so far is " + totalTax);

			// Taxpayer ID Rerun
			System.out.print("\nPlease enter your taxpayer ID (or 0 to quit): ");
			id = keyboard.nextInt();

		} // id while loop

		// Overall Calculations (outside loop)
		if (numOfTaxpayers > 0) {
			averageTax = overallTax / numOfTaxpayers;
		} // Taxpayers greater than 0 if statement
		else {
			averageTax = 0.0;
		} // Taxpayers equal to 0 if statement

		// Overall Calculations Displayed
		System.out.println("Total number of taxpayers: " + numOfTaxpayers + ".");
		System.out.printf("The highest tax amount was $%1.2f", highestTax,
				", which was paid by ID " + highestTaxID + ".");
		System.out.printf("\nThe total amount of taxes that were paid is $%1.2f", overallTax);
		System.out.printf("\nThe average amount of tax paid is $%1.2f", averageTax);
		System.out.println("\nThank you for using this program! Goodbye!");
		keyboard.close();

	} // main

} // TaxesGolusinski