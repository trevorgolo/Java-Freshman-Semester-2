/**
* @author Trevor Golusinski <br>
* Prog 8 <br>
* Due Date and Time: April 29th, 2021 before 9:00 AM <br>
*
* Purpose: The purpose of this program is to assist a user in shopping, by keeping
*			track of their items, costs, and names of items, with the initial
*			items being collected from a file. It will also sort the items in
*			the list via their names. <br>
*
* Input: The user will input a file name, then input their menu choice, and will 
* 			follow the on-screen instructions that are displayed after each choice. <br>
*
* Output: The program will output a response to every user input, and will display
*			information such as number of items, cost of each item, item names,
*			etc, all based on user input. <br>
*
* Certification of Authenticity:
* I certify that this lab is entirely my own work. <br>
 */
public class KeyedListGolusinski 
{
	/**
	 * Instance array to hold the user's items.
	 */
	ItemGolusinski[] myItems;
	
	/**
	 * Instance variable to hold the size of the array.
	 */
	int mySize;
	
	/**
	 * The null constructor that will initialize the size of the list, as well as
	 * the size, and set all items in the list to null.
	 */
	public KeyedListGolusinski()
	{
		myItems = new ItemGolusinski[20];
		mySize = 0;
		
		//Initialize each item to null 
		for (int i = 0; i < myItems.length; i++)
		myItems[i] = null;	
	}//KeyedListGolusinski
	
	/**
	 * The clear() method will set the size of the list equal to 0, effectively clearing
	 * the list of all elements.
	 */
	public void clear()
	{
		mySize = 0;
	}//clear
	
	/**
	 * The findIndex() helper method will search through the entire array of items 
	 * until either it finds the item, or it reaches the end of the populated portion.
	 * @param keyValue - The name of the item that the user wishes to find.
	 * @return Either a negative number, indicating that the item does not exist,
	 * or the index location of the item.
	 */
	private int findIndex(String keyValue)
	{
		int index = -1;
		String name;
		for (int i = 0; i < mySize; i++)
		{
			name = myItems[i].getName();
			if (name.equalsIgnoreCase(keyValue))
				index = i;
		}//for
		return index;
	}//findIndex
	
	/**
	 * The add() method will add an item to the array, ensuring that it is placed
	 * correctly, in alphabetical order. It will shift over any items that are
	 * ahead of the item's designated spot, in order to make space.
	 * @param product - The item information that the user entered.
	 * @return True or False, indicating whether the item was successfully added or not.
	 */
	public boolean add(ItemGolusinski product)
	{
		int i = 0;
		boolean ans = false;
		String key = null;
		if((mySize < myItems.length) && (findIndex(product.getName()) == -1))
		{
			if (mySize == 0)
				myItems[i] = product;
			key = myItems[i].getName();
			String productKey = product.getName();
			while ((i < mySize) && (productKey.compareToIgnoreCase(key) > 0))
			{
				key = myItems[i].getName();
				i++;
			}//while
			for (int j = mySize - 1; j >= i; j--)
				myItems[j + 1] = myItems[j];
			myItems[i] = product;
			mySize++;
			ans = true;
		}//if
		return ans;
	}//add
	
	/**
	 * The remove() method will remove an item from the list, and shift all items
	 * ahead of it backward, such that they fill in the gaps. It will then remove
	 * the last item, to avoid duplicates.
	 * @param keyValue - The name of the item that the user wishes to remove.
	 * @return True or False, indicating whether the item was successfully removed or not.
	 */
	public boolean remove(String keyValue)
	{
		boolean ans = false;
		int location = findIndex(keyValue);
		if (location != -1)
		{
			myItems[location] = null;
			for (int j = location; j < mySize; j++)
				myItems[j] = myItems[j + 1];
			myItems[mySize - 1] = null;
			mySize--;
			ans = true;
		}//if
		return ans;
	}//remove
	
	/**
	 * The retrieve() method will first ensure that the item in question exists, and
	 * if so, it will return details on the item.
	 * @param keyValue - The item name that the user wishes to find.
	 * @return Details on the item, or null if the item does not exist.
	 */
	public ItemGolusinski retrieve(String keyValue)
	{
		ItemGolusinski ans = null;
		int location = findIndex(keyValue);
		if (location != -1)
			ans = myItems[location];
		return ans;
	}//retrieve
	
	/**
	 * The isEmpty() method will check if mySize is greater than 0, checking whether
	 * there are items in the list.
	 * @return True or False, indicating whether the array is empty or not.
	 */
	public boolean isEmpty()
	{
		boolean ans = true;
		if (mySize > 1)
			ans = false;
		return ans;
	}//isEmpty
	
	/**
	 * The isFull() method will check if mySize is less than 20, checking whether
	 * the array is full or not.
	 * @return True or False, indicating whether the array is full or not.
	 */
	public boolean isFull()
	{
		boolean ans = true;
		if (mySize < 20)
			ans = false;
		return ans;
	}//isFull
	
	/**
	 * The print() method will print out details on every item in the list, including
	 * name, quantity, and individual price. If there are no items, it will inform
	 * the user that the list is empty.
	 */
	public void print()
	{
		int printCheck = 0;
		for (int i = 0; i < mySize; i++) 
		{	
			System.out.println("Item " + (i + 1) + ": ");
			System.out.println(myItems[i].toString());
			printCheck++;
		} // for loop
		if (printCheck == 0)
			System.out.println("There are no items in the cart.");
	}//print
	
	/**
	 * The getCount() method will calculate the total number of items in the cart.
	 * @return The sum of the quantities of each item.
	 */
	public int getCount()
	{
		int sum = 0;
		for (int i = 0; i < mySize; i++)
			sum = sum + myItems[i].getQuant();
		return sum;
	}//getCount
	
	/**
	 * The calcTotal() method will calculate the total cost of all items in the cart,
	 * by multiplying the cost and the quantities of each item.
	 * @return The total cost of all items in the cart
	 */
	public double calcTotal()
	{
		double total = 0;
		double sum = 0;
		for (int i = 0; i < mySize; i++)
		{
			sum = myItems[i].getPrice() * myItems[i].getQuant();
			total = total + sum;
		}//for
		return total;
	}//calcTotal
}//KeyedListGolusinski
