import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.*;
/**
* @author Trevor Golusinski <br>
* Prog 8 <br>
* Due Date and Time: April 29th, 2021 before 9:00 AM <br>
*
* Purpose: The purpose of this program is to assist a user in shopping, by keeping
*			track of their items, costs, and names of items, with the initial
*			items being collected from a file. It will also sort the items in
*			the list via their names. <br>
*
* Input: The user will input a file name, then input their menu choice, and will 
* 			follow the on-screen instructions that are displayed after each choice. <br>
*
* Output: The program will output a response to every user input, and will display
*			information such as number of items, cost of each item, item names,
*			etc, all based on user input. <br>
*
* Certification of Authenticity:
* I certify that this lab is entirely my own work. <br>
 */
public class ShoppingDemoGolusinski 
{
	/**
	 * Declaration statement to initialize a scanner to intake user input.
	 */
	static Scanner keyboard = new Scanner(System.in);
	
	/**
	 * A DecimalFormat variable to ensure that all money-related values are printed
	 * in a money-style format ($.$$).
	 */
	static DecimalFormat moneyStyle = new DecimalFormat("0.00");

	/**
	 * The main method, where all of the method referencing and most of the
	 * display will take place.
	 * @param args An array of strings that is used by the main method.
	 */
	public static void main(String[] args) 
	{
		//Instance variables
		KeyedListGolusinski cart = new KeyedListGolusinski();
		String fakeMenuInput;
		char menuInput;
		String name = "";
		int quantity = 0;
		double price = 0;
		boolean addedToCart;
		boolean result;
		String fileName = null;
		int numItems = 0;
		Boolean read = false;
		ItemGolusinski item = new ItemGolusinski(name, quantity, price);
	    
		System.out.println("Welcome! This program will help you go shopping!");
		
	    do 
	    {
	    	//Consistently loop through the code until the user enters a valid file.
	    	System.out.print("Please enter the initial file name: ");
		    fileName = keyboard.next();
		    File initialFile = new File(fileName);
	    	try
		    {
		    	Scanner input = new Scanner(initialFile);
			    numItems = input.nextInt();
			    for (int i = 0; i < numItems; i++)
			    {
			    	//Add each item to the cart
			    	name = input.next();
			    	quantity = input.nextInt();
			    	price = input.nextDouble();
			    	item = new ItemGolusinski(name, quantity, price);
					addedToCart = cart.add(item);
			    }//for loop
			    input.close();
			    System.out.println("Items in file successfully added to cart!");
			    read = true;
		    }//try
		    catch(FileNotFoundException ex)
		    {
		    	System.out.println("Could not find file: " + initialFile.getAbsolutePath()); 
		    }//catch: file not found
		    catch(InputMismatchException ex)
		    {
		    	System.out.println("Type mismatch for the number I just tried to read.");
		        System.out.println(ex.getMessage());
		    }//catch: type mismatch
		    catch(NumberFormatException ex)
		    {
		    	System.out.println("Failed to convert String text into an integer value.");
		    	System.out.println(ex.getMessage());
		    }//catch: converting string to integer
		    catch(NullPointerException ex)
		    {
		    	System.out.println("Null pointer exception.");
		    	System.out.println(ex.getMessage());
		    }//catch: value is null
		    catch(Exception ex)
		    {	    	
		    	System.out.println("Something went wrong");
		    	ex.printStackTrace();
		    }//catch: other error
	    }//Read file loop
	    while (read == false);
	    
		do 
		{
			//menu
			System.out.println("\nPlease choose an item from the following menu:"
					+ "\n1. Add an Item to the List"
					+ "\n2. Delete an Item From the List"
					+ "\n3. Print Each Item in the List"
					+ "\n4. Search for a User-Specified Item in the List"
					+ "\n5. Count the Total Number of Items in the List"
					+ "\n6. Total the Cost of the Items in the List" 
					+ "\n7. Determine Whether the List is Empty"
					+ "\n8. Determine Whether the List is Full"
					+ "\n9. Clear the List"
					+ "\n0. Quit");
			System.out.print("Please select an item: ");
			fakeMenuInput = keyboard.next();
			fakeMenuInput = fakeMenuInput.toLowerCase();
			menuInput = fakeMenuInput.charAt(0);

			//A switch statement to use a case-by-case basis for each user input.
			switch (menuInput) 
			{
			case '1':
				System.out.print("Please enter the item name: ");
				name = keyboard.next();
				System.out.print("Please enter the quantity: ");
				quantity = keyboard.nextInt();
				System.out.print("Please enter the individual price of the item: ");
				price = keyboard.nextDouble();
				item = new ItemGolusinski(name, quantity, price);
				addedToCart = cart.add(item);
				if (addedToCart) 
					System.out.println(name + " has been added to the cart!");
				else
					System.out.println(name + " could not be added to the cart.");
				break;
			case '2':
				System.out.print("Please enter the name of the item you wish to delete: ");
				name = keyboard.next();
				result = cart.remove(name);
				if (result)
					System.out.println(name + " has been removed!");
				else
					System.out.println("Sorry, you do not have " + name + " in the list.");
				break;
			case '3':
				cart.print();
				break;
			case '4':
				System.out.print("Please enter the name of the item you wish to retrieve: ");
				name = keyboard.next();
				item = cart.retrieve(name);
				if (item != null)
					System.out.println("Yes, you have " + item.getQuant() + " " + item.getName() + " at $" + moneyStyle.format(item.getPrice()) + " each.");
				else
					System.out.println("Sorry, " + name + " is not in the list.");
				break;
			case '5':
				System.out.println("There are " + cart.getCount() + " items in the list.");
				break;
			case '6':
				System.out.println("The total cost of all items in the list is $" + moneyStyle.format(cart.calcTotal()));
				break;
			case '7':
				if (cart.isEmpty())
					System.out.println("The list is empty.");
				else
					System.out.println("The list is not empty.");
				break;
			case '8':
				if (cart.isFull())
					System.out.println("The list is full.");
				else
					System.out.println("The list is not full.");
				break;
			case '9':
				cart.clear();
				System.out.println("The cart has been cleared!");
				break;
			case '0':
				System.out.println("Thank you for using this program! Goodbye!");
				break;
			default:
				System.out.print("Unable to read input. Please try again: ");
			}// switch statement
		} // large do loop
		while (menuInput != '0');

		keyboard.close();
	}// main
}// ShoppingDemoGolusinski
