import java.util.*;

public class methodsExampleHandout {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		 int taxID, filingStatus, numHours, numExemptions;
		 double payRate, grossIncome, taxRate, taxDue;
		
		 //get the input
		 System.out.println("Enter TaxpayerID: ");
		 taxID = keyboard.nextInt();
		 System.out.println("Filing Status: ");
		 filingStatus = keyboard.nextInt();
		 System.out.println("Enter number of hours worked: ");
		 numHours = keyboard.nextInt();
		 System.out.println("Enter hourly pay rate: ");
		 payRate = keyboard.nextDouble();
		 System.out.println("Enter number of exemptions: ");
		 numExemptions = keyboard.nextInt();
		
		 // get the gross income
		 grossIncome = calcGrossIncome(numHours, payRate);
		
		 // get the tax rate
		 taxRate = calcTaxRate(filingStatus, grossIncome);
		
		 // get the tax due
		 taxDue = calcTaxDue(grossIncome, taxRate);
		
		 // output the results
		 outputResults(taxID, filingStatus, numHours, payRate, numExemptions,
		 grossIncome, taxRate, taxDue);
		 
		 keyboard.close();
	}//main
	
	public static double calcGrossIncome(int hours, double rate)
	 {
		double totalGrossIncome = hours * rate;
		return totalGrossIncome;
	 } //calcGrossIncome
	
	 public static double calcTaxRate(int status, double income)
	 {
		 double rate;
		 if (status == 1) 
		 {
			 rate = .25;
		 } else if (status == 2) 
		 {
			 rate = .3;
		 } else 
		 {
			 rate = .35;
		 }
		 return rate;
	 } //calcTaxRate
	
	 public static double calcTaxDue(double income, double rate)
	 {
		 double tax = income * rate;
		 return tax;
	 } //calcGrossIncome
	 
	 public static void outputResults(int id, int status, int hours, double pay, int exemptions, double income, double tax, double due)
	 {
		 System.out.println("The taxpayer's ID is " + id);
		 System.out.println("The taxpayer has worked " + hours + " hours.");
		 System.out.println("The taxpayer is paid $" + pay + " per hour.");
		 System.out.println("The taxpayer has " + exemptions + " exemption(s).");
		 System.out.printf("Their gross income is $%1.2f", income);
		 System.out.println("\nTheir tax rate is " + tax);
		 System.out.printf("The total amount of tax due is $%1.2f", due);
		 
	 }//outputResults
	 
 }//MethodsExampleHandout

