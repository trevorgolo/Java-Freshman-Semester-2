//
// Trevor Golusinski
// Prog 3
// Due Date and Time: March 22, 2021 before 9:00 AM
//
// Purpose: This program will calculate and display 
//			hospital fees for a user based on several
//			criteria that they will enter.
//
// Input: The user will input their patient ID, household income,
//			insurance plan, and days spent in the hospital,
//			in that order.
//
// Output: The program will output the total bill cost,
//			number of patients, highest bill amount and the patient's ID,
//			the lowest bill cost as well as the patient's ID,
//			the total cost of all the bills, and the average cost.
//
// Certification of Authenticity:
// I certify that this lab is entirely my own work.

import java.util.*;

public class HospitalGolusinski {

	static Scanner keyboard = new Scanner(System.in);

	public static void main(String[] args) {
		int admittance = 400;
		int id = 1;
		double income = -1;
		String fakePlan;
		char realPlan;
		int days = 0;
		int diemCharge = 0;
		int serviceFee = 0;
		int discount = 0;
		double total = 0;
		int patients = 0;
		double highestBill = 0;
		int highestID = 0;
		double lowestBill = 0;
		int lowestID = 0;
		double totalBills = 0;
		double averageBills = 0;
		// Intro
		System.out.println(
				"Welcome! This program will calculate your total bill cost " + "for your stay at the hospital!");

		// Patient ID
		System.out.print("Please enter your Patient ID (or 0 to quit): ");
		id = keyboard.nextInt();

		while (id != 0) {
			realPlan = 0;
			// Household Income
			do {
				System.out.print("Please enter your household income: ");
				income = keyboard.nextDouble();
			} // Income do loop
			while (income < 0);

			// Insurance Plan
			System.out.print("Please enter your insurance plan:" + "\nG for Green Plus" + "\nD for Doc-Health"
					+ "\nH for Heath Plan" + "\nN for No Insurance" + "\nYour plan: ");
			do {
				fakePlan = keyboard.next();
				fakePlan = fakePlan.toLowerCase();
				realPlan = fakePlan.charAt(0);
				switch (realPlan) {
				case 'g':
					break;
				case 'd':
					break;
				case 'h':
					break;
				case 'n':
					break;
				default:
					System.out.print("Unable to read input. Please try again: ");
				} // Plan switch loop
			} // Plan do loop
			while ((realPlan != 'g') && (realPlan != 'd') && (realPlan != 'h') && (realPlan != 'n'));

			// Number of Days
			do {
				System.out.print("Please enter the number of days you spent in the hospital: ");
				days = keyboard.nextInt();
			} // Days do loop
			while ((days < 1) || (days > 365));

			// calcPerDiem call
			diemCharge = calcPerDiem(realPlan, income);

			// calcServiceFee call
			serviceFee = calcServiceFee(diemCharge, days);

			// calcDiscount call
			discount = calcDiscount(days);

			// calcTotalBill call
			total = calcTotalBill(serviceFee, discount);

			// outputResults call
			outputResults(id, income, realPlan, days, admittance, diemCharge, serviceFee, discount, total);

			// Inside loop calculations
			if (lowestBill == 0) {
				lowestBill = total;
				lowestID = id;
			} // lowest bill 0 check
			
			patients++;
			
			if (total > highestBill) {
				highestBill = total;
				highestID = id;
			} // highest bill check
			else if (total < lowestBill) {
				lowestBill = total;
				lowestID = id;
			} // Lowest bill check
			
			totalBills = totalBills + total;

			// Patient ID check 2
			System.out.print("\nPlease enter another Patient ID (or 0 to quit): ");
			id = keyboard.nextInt();

		} // id while loop

		// Final output
		System.out.println("\nTotal number of patients processed: " + patients);
		System.out.printf("The highest bill amount was: $%1.2f", highestBill);
		System.out.println("\nThe highest bill was paid by id " + highestID);
		System.out.printf("The lowest bill amount was: $%1.2f", lowestBill);
		System.out.println("\nThe lowest bill was paid by id " + lowestID);
		System.out.printf("The total cost of all bills was $%1.2f", totalBills);
		if (patients > 0) {
			averageBills = totalBills / patients;
		} // averages if statement
		else {
			averageBills = 0.0;
		} // averages else statement
		System.out.printf("\nThe average cost of all bills was $%1.2f", averageBills);
	}// main

	public static int calcPerDiem(char plan, double houseIncome) {
		int charge = 0;
		switch (plan) {
		case 'g':
			if (houseIncome < 20000) {
				charge = 65;
			} // Less than 20000 g
			else if (houseIncome <= 77500) {
				charge = 80;
			} // Less than or equal to 77,500 g
			else {
				charge = 150;
			} // Greater than 77,500 g
			break;
		case 'd':
			if (houseIncome < 40000) {
				charge = 60;
			} // Less than 40,000 d
			else if (houseIncome <= 75000) {
				charge = 90;
			} // Less than or equal to 75,000 d
			else {
				charge = 140;
			} // Greater than 75,000 d
			break;
		case 'h':
			if (houseIncome < 17500) {
				charge = 55;
			} // Less than 17,500 h
			else if (houseIncome <= 53000) {
				charge = 70;
			} // Less than or equal to 53,000
			else {
				charge = 130;
			} // Greater than 53,000
			break;
		case 'n':
			charge = 400;
			break;
		}// Insurance Plan switch statement
		return charge;
	}// calcPerDiem

	public static int calcServiceFee(int diem, int daysSpent) {
		int fee = diem * daysSpent;
		return fee;
	}// calcServiceFee

	public static int calcDiscount(int timeSpent) {
		int costDiscount = 0;
		if (timeSpent > 21) {
			int weeks = timeSpent / 7;
			costDiscount = weeks * 250;
		} // timeSpent if statement
		return costDiscount;
	}// calcDiscount

	public static double calcTotalBill(int fee, int billDiscount) {
		int totalBill = fee + 400;
		totalBill = totalBill - billDiscount;
		return totalBill;
	}// calcTotalBill

	public static void outputResults(int patientID, double householdIncome, char insurancePlan, int daysSpent,
			int admittanceFee, int diemFee, int serviceCost, int discountAmount, double totalCost) {
		System.out.println("\nPatient ID: " + patientID);
		System.out.printf("Patient's household income: $%1.2f", householdIncome);
		System.out.print("\nPatient's insurance plan: ");
		switch (insurancePlan) {
		case 'g':
			System.out.println("Green Plus");
			break;
		case 'd':
			System.out.println("Doc-Health");
			break;
		case 'h':
			System.out.println("Health Plan");
			break;
		case 'n':
			System.out.println("No Insurance");
		}// Insurance Plan switch statement
		System.out.println("Number of days spent: " + daysSpent);
		System.out.println("Admittance fee: $" + admittanceFee);
		System.out.println("Per diem rate: $" + diemFee);
		System.out.println("Service fee: $" + serviceCost);
		System.out.println("Discount: $" + discountAmount);
		System.out.printf("Total bill cost: $%1.2f", totalCost);
	}// outputResults
}// HospitalGolusinski