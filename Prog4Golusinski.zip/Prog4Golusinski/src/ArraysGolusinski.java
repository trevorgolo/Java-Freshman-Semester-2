//
// Trevor Golusinski
// Prog 4
// Due Date and Time: March 29, 2021 before 9:00 AM
//
// Purpose: This program will use arrays to give the user
//  		outputs based on their choice of menu item.
//
// Input: The user will input their menu choice, and will
//			also input par values, grades, or set of numbers,
//			based on which item they chose from the menu.
//
// Output: The program will output a list of par classifications,
//			high, low, and average grades, or how many times
//			a certain number shows up in a list of numbers, all
//			based on the user's menu input.
//
// Certification of Authenticity:
// I certify that this lab is entirely my own work.

import java.util.*;

public class ArraysGolusinski 
{

	static Scanner keyboard = new Scanner(System.in);

	// This is the main method, where all of the calls to other
	// methods will take place.
	public static void main(String[] args) 
	{
		String fakeChoice;
		char realChoice;
		int i = 0;
		double[] grades = new double[10];
		double currentGrade = 0;
		double high = 0;
		double low = 0;
		double average = 0;
		int num = 0;
		int count = 0;

		System.out.println("Welcome! This program will allow you " + "to enter par values for golf, grades, or a list "
				+ "of numbers! Choose an option below to continue!");
		System.out.println("1) Let's Go Golfing!" + "\n2) Handle Grades" + "\n3) How Many Maxes?" + "\n0) Quit");
		System.out.print("What would you like to do: ");
		fakeChoice = keyboard.next();
		realChoice = fakeChoice.charAt(0);
		do 
		{
			switch (realChoice) 
			{
			case '0':
				break;
			case '1':
				break;
			case '2':
				break;
			case '3':
				break;
			default:
				System.out.print("Unable to read input. Please try again: ");
				fakeChoice = keyboard.next();
				realChoice = fakeChoice.charAt(0);
			}// choice validation switch loop
		} // do loop
		while ((realChoice != '0') && (realChoice != '1') && (realChoice != '2') && (realChoice != '3'));
		
		while (realChoice != '0') 
		{
			switch (realChoice) 
			{
			case '0':
				break;
			case '1':
				parValues();
				break;
			case '2':
				System.out.println("Please enter 10 grades, one at a time.");
				for (i = 0; i < grades.length; i++) 
				{
					do
					{
						System.out.print("Please enter grade " + (i + 1) + ": ");
						currentGrade = keyboard.nextDouble();
					} //logical grade do loop
					while ((currentGrade < 0) || (currentGrade > 100));
					grades[i] = currentGrade;
				} // grade obtaining for loop
				high = highGrade(grades);
				System.out.println("The highest grade is: " + high);
				low = lowGrade(grades);
				System.out.println("The lowest grade is: " + low);
				average = averageGrade(grades);
				System.out.printf("The average of the grades is: %1.2f", average);
				break;
			case '3':
				count = 0;
				int [] integers = new int[8];
				System.out.println("Please enter up to 8 positive integers, or a negative integer when finished.");
				System.out.print("Please enter integer " + (count + 1) + ": ");
				num = keyboard.nextInt();
				while ((num >= 0) && (count < integers.length)) 
				{
					integers[count] = num;
					count++;
					if (count <= 7)
					{
					System.out.print("Please enter integer " + (count + 1) + ": ");
					num = keyboard.nextInt();
					}//Preventng number 9 if statement
				} // while loop
				integerResponse(integers);
				break;
			}// choice action switch loop

			System.out.println("\nWelcome back to the menu!" + "\n1) Let's Go Golfing!" + "\n2) Handle Grades"
					+ "\n3) How Many Maxes?" + "\n0) Quit");
			System.out.print("What would you like to do: ");
			fakeChoice = keyboard.next();
			realChoice = fakeChoice.charAt(0);
			do 
			{
				switch (realChoice) 
				{
				case '0':
					break;
				case '1':
					break;
				case '2':
					break;
				case '3':
					break;
				default:
					System.out.print("Unable to read input. Please try again: ");
					fakeChoice = keyboard.next();
					realChoice = fakeChoice.charAt(0);
				}// choice validation switch loop
			} // do loop
			while ((realChoice != '0') && (realChoice != '1') && (realChoice != '2') && (realChoice != '3'));
		} // huge do while loop
		System.out.println("Thank you for using this program! Goodbye!");
		keyboard.close();
	}// main

	// This method will gather the hole's par count, as well as
	// the amount of strokes the user took on each hole.
	public static void parValues() 
	{
		int i = 0;
		int parCount = 0;
		int playerPar = 0;
		int parList[] = new int[9];
		int[] playerResults = new int[9];
		System.out.println("Please enter nine hole par values.");
		for (i = 0; i < parList.length; i++) {
			do
			{
				System.out.print("Please enter par value for hole " + (i + 1) + ": ");
				parCount = keyboard.nextInt();
			}//logical par count do loop
			while (parCount <= 0);
			parList[i] = parCount;
		} // par count list for loop

		System.out.println("Please enter your number of strokes for each hole.");
		for (i = 0; i < parList.length; i++)
		{
			do
			{
				System.out.print("Please enter your stroke count for hole " + (i + 1) + ": ");
				playerPar = keyboard.nextInt();	
			}//logical stroke count do loop
			while (playerPar <= 0);
			playerResults[i] = playerPar;
		} // player par list for loop

		parCalc(parList, playerResults);
	}// parValues

	// This method will compare the hole pars with the player's
	// stroke numbers, and print out the number of Eagles,
	// Birdies, Pars, Bogeys, Double Bogeys, and Others.
	public static void parCalc(int[] parValues, int[] playerPars) 
	{
		int i = 0;
		int eagles = 0;
		int birdies = 0;
		int pars = 0;
		int bogeys = 0;
		int doubleBogeys = 0;
		int others = 0;
		for (i = 0; i < playerPars.length; i++) {
			if (playerPars[i] == (parValues[i] + 2)) 
			{
				eagles++;
			} // Eagles if statement
			else if (playerPars[i] == (parValues[i] + 1)) 
			{
				birdies++;
			} // Birdies if statement
			else if (playerPars[i] == parValues[i])
			{
				pars++;
			} // Pars if statement
			else if (playerPars[i] == (parValues[i] - 1)) 
			{
				bogeys++;
			} // Bogeys if statement
			else if (playerPars[i] == (parValues[i] - 2))
			{
				doubleBogeys++;
			} // doubleBogeys if statement
			else {
				others++;
			}
		} // Results for loop
		System.out.println("Total number of Eagles: " + eagles);
		System.out.println("Total number of Birdies: " + birdies);
		System.out.println("Total number of Pars: " + pars);
		System.out.println("Total number of Bogeys: " + bogeys);
		System.out.println("Total number of Double Bogeys: " + doubleBogeys);
		System.out.println("Total number of Others: " + others);
	}// parCalc

	// This method calculates the highest grade in the given set
	// from the user.
	public static double highGrade(double[] grade)
	{
		int i = 0;
		double highestGrade = 0;
		for (i = 1; i < grade.length; i++) 
		{
			if (grade[i] > highestGrade)
				highestGrade = grade[i];
		} // highGrade for loop
		return highestGrade;
	}// highGrade

	// This mthod calculates the lowest grade in the given set
	// from the user.
	public static double lowGrade(double[] grade) 
	{
		int i = 0;
		double lowestGrade = 0;
		lowestGrade = grade[0];
		for (i = 1; i < grade.length; i++)
		{
			if (grade[i] < lowestGrade)
				lowestGrade = grade[i];
		} // highGrade for loop
		return lowestGrade;
	}// lowGrade

	// This method calculates the average of all the grades
	// given by the user.
	public static double averageGrade(double[] grade) 
	{
		int i = 0;
		double average = 0;
		int count = 0;
		double total = 0;
		for (i = 0; i < grade.length; i++) 
		{
			total = total + grade[i];
			count++;
		} // for loop
		average = total / count;
		return average;
	}// averageGrade

	// This method calculates the highest number in a given set
	// from the user, as well as how many times the number
	// appears in the set.
	public static void integerResponse(int[] intList)
	{
		int i = 0;
		int highest = 0;
		int count = 0;
		System.out.print("The list of numbers are: ");
		for (i = 0; i < intList.length; i++)
			System.out.print(intList[i] + " ");
		for (i = 1; i < intList.length; i++) 
		{
			if (intList[i] > highest)
				highest = intList[i];
		} // for loop
		for (i = 0; i < intList.length; i++)
			if (intList[i] == highest)
				count++;
		System.out.println("\nThe highest number in the list is: " + highest);
		if (count > 1)
			System.out.println("The number appears " + count + " times in the list.");
		else
			System.out.println("The number appears " + count + " time in the list.");
	}// integerResponse
}// ArraysGolusinski